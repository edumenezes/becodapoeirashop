/**
 * Spring Data JPA repositories.
 */
package io.github.jhipster.application.repository;
