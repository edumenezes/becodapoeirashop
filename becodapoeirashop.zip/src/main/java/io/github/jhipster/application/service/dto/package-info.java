/**
 * Data Transfer Objects.
 */
package io.github.jhipster.application.service.dto;
